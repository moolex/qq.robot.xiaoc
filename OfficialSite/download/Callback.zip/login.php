<?php

echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';

include "api.class.php";

$api = QQRobot_API::getInstance();

$config = array
(
	// 如果要从外部控制登陆的话，这里需要修改成外网IP，不然没法获取验证码
	'server' => '127.0.0.1',
	'port' => '8090',
	// 连接密钥，需要和API服务器的配置一样
	'seckey' => 'QQRobot.Moyo.(C).im.uuland.org'
);
// 账号和密码
$account = array
(
	'uid' => '752329591',
	'password' => '********'
);

$api->config($config);

// 测试服务器
echo $api->hello();
echo '<hr/>';

// 发送验证码
if (isset($_GET['verify']))
{
	echo '正在发送验证码[ '.$_GET['verify'].' ]...';
	echo $api->command('login.verify', array('verify'=>$_GET['verify']));
	echo '<hr/>';
}

// 检查状态
$status = $api->command('login.check');
if ($status  == 'ALREADY LOGIN')
{
	echo '已经登录';
	if (isset($_GET['verify']))
	{
		// 重定向到主页
		exit('<script>window.location="login.php";</script>');
	}
}
elseif ($status == 'NOT LOGIN')
{
	echo '正在登陆...';
	// 登陆
	echo $api->command('login.create', $account);
	// 重定向到主页
	echo '<script>window.location="login.php";</script>';
}
elseif ($status == 'WAIT VERIFY')
{
	echo '输入验证码：<form action="?" method="get"><input type="text" name="verify"/><img src="http://'.$config['server'].':'.$config['port'].'/v?'.$account['uid'].'"/><input type="submit" value="LOGIN"/></form>';
}

?>