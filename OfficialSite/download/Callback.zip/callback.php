<?php

$admin = '7052991';

include "api.class.php";

$api = QQRobot_API::getInstance();

$config = array
(
	'server' => '127.0.0.1',
	'port' => '8090',
	'seckey' => 'QQRobot.Moyo.(C).im.uuland.org',
);

$api->config($config);

$event = $_POST['event'];

switch ($event)
{
	case 'buddy.message':
		$uid = $_POST['uid'];
		$message = $_POST['message'];
		$send = '你的QQ是['.$uid.']，你刚才发的是：'.$message;
		$api->command('buddy.send', array('uid'=>$uid, 'message'=>$send));
	break;
	case 'qun.message':
		$gid = $_POST['gid'];
		$uid = $_POST['uid'];
		$message = $_POST['message'];
		$send = '收到来自内部群号['.$gid.']QQ号['.$uid.']的消息：'.$message;
		$api->command('qun.send', array('gid'=>$gid, 'message'=>$send));
	break;
	case 'system.message':
		$message = $_POST['message'];
		$send = '收到系统消息：'.$message;
		$api->command('buddy.send', array('uid'=>$admin, 'message'=>$send));
	break;
	case 'buddy.operate':
		$message = $_POST['message'];
		$send = '收到好友操作信息：'.$message;
		$api->command('buddy.send', array('uid'=>$admin, 'message'=>$send));
	break;
	default:
		echo '<result>failed</result>';
	exit;
}
?>
<result>success</result>